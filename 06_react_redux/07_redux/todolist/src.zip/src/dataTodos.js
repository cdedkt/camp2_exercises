const todos =
[
  { "id": "1", "label": "Développement reactJs", "done": true },
  { "id": "2", "label": "Révision fonction callback", "done": false },
  { "id": "3", "label": "Déploiement application ", "done": false }
];

export default todos;
