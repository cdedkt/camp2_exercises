import React, { Component } from 'react';
import { connect } from "react-redux";

class TableTodoRow extends Component {
  constructor(props) {
    super(props);

    this.handleInputChange = this.handleInputChange.bind(this);
  }

  getDeletedButton(todo) {
    if (todo.done) {
      return (<input type="button" name="isDeleted" value="Delete" id={todo.id} onClick={this.handleInputChange}/>);
    }
  }

  handleInputChange(event) {
    event.preventDefault();
    const target = event.target;
    const value = target.type === "checkbox" ? target.checked : target.value;
    const name = target.name;

    if (name === "isChecked") {
      this.props.checkTodo(this.props.todo.id);
    }

    if (name === "isDeleted") {
      //alert('This todo was submitted: ' + target.id);
      this.props.actionDeleteTodo(target.id);
      //this.props.fct(target.id);
    }
  }

  render() {
    console.log("RENDER TableTodoRow =", this.props);

    return (
      <tr>
        <td>{this.props.todo.id}</td>
        <td>{this.props.todo.label}</td>
        <td>
          <input
            name="isChecked"
            type="checkbox"
            id={this.props.todo.id}
            checked={this.props.todo.done}
            onChange={this.handleInputChange} />
        </td>
        <td>
          {this.getDeletedButton(this.props.todo)}
        </td>
      </tr>
    );
  }
}

function mapStateToProps(state) {
  return {  }
}

function mapDispatchToProps(dispatch) {
  return {
    checkTodo: (_todoId) => dispatch({type: "CHECK_TODO", todoId: _todoId}),
    counterUp: () => dispatch({type: "COUNTER_UP"}),
  }
}

const Connected = connect(null, mapDispatchToProps)(TableTodoRow);
export default Connected;
