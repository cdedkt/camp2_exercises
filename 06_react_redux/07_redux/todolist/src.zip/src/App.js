import React, { Component } from 'react';
import { connect } from "react-redux";

import './App.css';

import TableTodos from './TableTodos';

class App extends Component {
  render() {
    return (
      <div className="App container">
        <span className="row">SortedBy : {this.props.sortedBy}</span>
        <span className="row">SortedDesc : {this.props.sortedDesc}</span>
        <TableTodos/>
      </div>
    );
  }
}


function mapStateToProps(state) {
  return {
    sortedBy: state.sortedBy,
    sortedDesc: state.sortedDesc,
  }
}

const ConnectedApp = connect(mapStateToProps)(App);
export default ConnectedApp;
