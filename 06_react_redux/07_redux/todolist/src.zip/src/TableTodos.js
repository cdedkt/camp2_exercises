import React, { Component } from 'react';
import { connect } from "react-redux";

import TableTodoRow from './TableTodoRow';
import _ from "underscore";

class TableTodos extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sorter: "label",
      desc: false,
      newTodoLabel: "",
      lastId: "100",
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

    this.deleteTodo = this.deleteTodo.bind(this);
  }

  capitalize(value) {
    const re = /(\b[a-z](?!\s))/g;
    return value.replace(re, function(x){return x.toUpperCase();});
  }

  getTodos() {
    const todos = _.sortBy(this.props.todoList, this.state.sorter);
    return this.state.desc ? todos.reverse() : todos;
  }

 nextId() {
   this.setState({
     lastId: this.state.lastId + 1
   });
   return this.state.lastId;
 }

  addTodo() {
    if (this.state.newTodoLabel !== "") {
      this.setState({
        todoList: [...this.state.todoList, {
          id: this.nextId(),
          label: this.state.newTodoLabel,
          done: false
        }],
        newTodoLabel: ""
      });
    }
  }



  deleteTodo(todoId) {
    console.log("deleteTodo debut", todoId);
    const otherTodos = _.reject(this.state.todoList, function(todo){ return todo.id === todoId; });
    //console.log(otherTodos);
    this.setState({
      todoList: otherTodos
    });
  }

  handleColumnClick(newSorter) {
    this.setState({
        sorter: newSorter,
        desc: (newSorter === this.state.sorter) && !this.state.desc
    });
  }

  handleChange(event) {
    this.setState({newTodoLabel: this.capitalize(event.target.value)});
  }

  handleSubmit(event) {
    //alert('A new Todo was submitted: ' + this.state.newTodoLabel);
    this.addTodo();
    event.preventDefault();
  }

  render() {
    console.log("RENDER TableTodos", this.props.todoList);
    return (
      <div className="container">
        <form className="mt-4" onSubmit={this.handleSubmit}>
          <label>
            <span className="mr-4">New Todo :</span>
            <input type="text" value={this.state.newTodoLabel} onChange={this.handleChange} />
          </label>
          <input type="submit" value="Submit" />
        </form>

        <table className="table table-striped mt-4">
          <thead>
            <tr>
              <th scope="col" onClick={() => this.handleColumnClick("id")}>id</th>
              <th scope="col" onClick={() => this.handleColumnClick("label")}>label</th>
              <th scope="col" onClick={() => this.handleColumnClick("done")}>done</th>
            </tr>
          </thead>
          <tbody>
            {this.props.todoList.map(atodo => {
              console.log(atodo)
              return (<TableTodoRow
                key={atodo.id}
                todo={atodo}
              />)
            })}
          </tbody>
        </table>

        <textarea style={{width:700, height:200}} value={JSON.stringify(this.props.todoList)} />
      </div>
    );
  }
}


function mapStateToProps(state) {
  return { todoList: state.todos }
}

function mapDispatchToProps(dispatch) {
  return {
    counterUp: () => dispatch({type: "COUNTER_UP"}),
  }
}

const Connected = connect(mapStateToProps, mapDispatchToProps)(TableTodos);
export default Connected;
