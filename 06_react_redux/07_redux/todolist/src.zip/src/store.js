import { createStore } from 'redux';
import _ from 'underscore';

import todosImport from './dataTodos';

const initialState = {
  todos: todosImport,
  sortedBy: "label",
  sortedDesc: false,
};

function checkTodo(todoList, todoId) {
  console.log("checkTodo debut", todoId);
  const todoToModify = _.findWhere(todoList, {id: todoId});
  //console.log(todoToModify);
  todoToModify.done = !todoToModify.done;
  //console.log(todoToModify);
  const otherTodos = _.reject(todoList, function(todo){ return todo.id === todoId; });
  //console.log(otherTodos);
  return [...otherTodos, todoToModify];
}


function todosReducer(state = initialState, action) {
  switch (action.type) {
    case "CHECK_TODO":
      console.log("CHECK_TODO", action.todoId);
      const newTodoList = checkTodo(state.todos, action.todoId);
      return {
        ...state,
        todos: newTodoList
      }

    case "ADD_TODO":
      console.log("ADD_TODO");
      const newTodo = action.todo;
      newTodo.id = "1000"; //this.nextId();
      newTodo.done = false;

      const newTodoListAdd = [ ...state.todos, newTodo ];
      return {
        ...state,
        todos: newTodoListAdd
      }

    default:
      return state
  }
}

const store = createStore(todosReducer);

export default store;
